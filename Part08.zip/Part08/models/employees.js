const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Weights', { useNewUrlParser: true });
const wSchema = new mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId,
  empName: String,
  empWeight: Number,
  created: {
        type: Date,
        default: Date.now
    }
});
module.exports = mongoose.model('Weights', wSchema);
