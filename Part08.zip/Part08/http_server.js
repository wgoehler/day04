const MongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017';
const dbName = 'Weights';
const mClient = new MongoClient(url, {
	useNewUrlParser: true
});
mClient.connect(function(err) {
	if(err) console.log("Error");
	const db = mClient.db(dbName);
  putDocuments(db, function(){
  	mClient.close();
	});
});
const putDocuments = function(db, callback) {
  const collection = db.collection('EmployeeWeights');
  collection.insertMany([
    	{"empName":"Axle", "empWeight" : "85.8"},
    	{"empName":"John", "empWeight" :"102"}
  	],
		function(err, result) {
			if(err) throw err;
			console.log("Inserted 2 documents/records");
    	callback(result);
  	}
	);
};
