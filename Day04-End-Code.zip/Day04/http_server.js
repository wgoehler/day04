const express= require('express');
const bodyParser = require('body-parser');
const routes = require('./routes/routes');
const m = require('./controllers/morgan_logs');
const port = 8000;
const app = express();
//app.use(bodyParser.json());
app.use(m);
app.use(bodyParser.urlencoded({extended:false}));
app.set('view engine', 'pug');
const router = express.Router();
routes(app);
//
app.use('/', router);
//
app.listen(port, function(){
	console.log("Listening " + port);
});
