const Weight = require('../models/employees');
const User = require('../models/users');
const jwt = require('jsonwebtoken');
const path = require("path");
exports.getdefault = function(req, res){
  res.sendFile(path.join(__dirname + '/../HTML/index.html'));
};
//
exports.aboutus=function(req, res){
    res.send('You are on the about us route.');
};
//
exports.employees=function(req, res){
  let empToFind = req.params.employeeName;
  Weight.find({empName:empToFind}, function(err, results){
    if (err)
      res.end(err);
    res.json(results);
  });
};
//
exports.deletebyname=function(req, res){
  let empToDelete = req.params.employeeName;
  Weight.deleteOne({empName:empToDelete}, function(err, results){
    if (err)
      res.end(err);
    res.end(`Deleted ${empToDelete}`);
  });
};
//
exports.getallrecords=function(req, res){
  Weight.find({}, function(err, results){
    if (err) res.end(err);
    res.json(results);
  });
};
//
exports.putnewdoc = function(req,res){
	let empName = req.body.empName;
	let empWeight = req.body.empWeight;
	const weight = new Weight();
	weight.empName = empName;
	weight.empWeight = empWeight;
 	weight.save({}, function(err) {
		if (err)
			res.end(err);
		res.end(JSON.stringify(`Created ${empName}`));
  });
};
//
exports.updatedoc = function(req,res){
  let fixName = req.body.empName;
  let newWeight = req.body.empWeight;
  let query = { empName : fixName };
  let data = { $set : {empWeight : newWeight } }

  Weight.updateOne(query, data, function(err, result) {
    if (err)
  res.send(err);
    res.end(`Updated ${fixName}`);
  });
};
//
exports.putnewuser = function(req,res){
	let empName = req.body.empName;
	let empPass = req.body.empPass;
	const user = new User();
	user.empName = empName;
	user.empPass = empPass;
 	user.save({}, function(err) {
		if (err)
			res.end(err);
		res.end(JSON.stringify(`Created new user ${empName}`));
  });
};
//
exports.loginuser = function(req,res){
	let empName = req.body.empName;
	let empPass = req.body.empPass;
	const user = new User();
  User.find({empName:empName}, function(err, results){
	  if (err)
	    res.end(err);
      if(results[0].empPass == empPass){
        jwt.sign({
          empName:results[0].empName,
          userID:results[0]._id
        },
        "mysecret",
        {expiresIn : "1h"},
        function(err, token){
          if(err) throw err;
          res.end(token);
        }
      )
    } else {
      res.end("Login failed");
    }
	});
};
//
exports.pughome=function(req, res){
  res.render('pughome');
};
