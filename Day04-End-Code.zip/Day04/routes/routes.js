module.exports = function(app){
  const express= require('express');
  app.use(express.static(__dirname + '/../HTML'));
  const authUser = require('../controllers/auth');
  let controller = require('../controllers/controller');
  app.route('/').get(controller.getdefault);
  app.route('/aboutus').get(controller.aboutus);
  app.route('/employees/:employeeName').get(controller.employees);
  app.route('/deletebyname/:employeeName').delete(controller.deletebyname);
  app.route('/getallrecords').get(controller.getallrecords);
  app.route('/putnewdoc').post(controller.putnewdoc);
  app.route('/updatedoc').put(controller.updatedoc);
  app.route('/putnewuser').post(controller.putnewuser);
  app.route('/loginuser').post(controller.loginuser);
  app.route('/pughome').get(controller.pughome);
};
