const Weight = require('../models/employees');
exports.getdefault = function(req, res){
    res.send('You are on the root route.');
};
//
exports.aboutus=function(req, res){
    res.send('You are on the about us route.');
};
//
exports.employees=function(req, res){
    res.send('You are viewing employee# ' + req.params.employeeName);
};
//
exports.getallrecords=function(request, response){
	Weight.find({}, function(err, results){
		if (err)
		    response.end(err);
		response.json(results);
	});
	//res.send('You are on the getallrecords route.');
};
//
exports.putnewdoc = function(req,res){
	let empName = req.body.empName;
	let empWeight = req.body.empWeight;
	const weight = new Weight();
	weight.empName = empName;
	weight.empWeight = empWeight;
 	weight.save({}, function(err) {
		if (err)
			res.end(err);
		res.end(`Created ${empName}`);
  });
};
//
exports.updatedoc = function(req, res) {
  let fixName = req.body.empName;
  let newWeight = req.body.empWeight;
  let query = { empName : fixName };
  let data = { $set : {empWeight : newWeight } }

  Weight.updateOne(query, data, function(err, result) {
    if (err)
     res.send(err);
    res.end(`Updated ${fixName}`);
});
};
